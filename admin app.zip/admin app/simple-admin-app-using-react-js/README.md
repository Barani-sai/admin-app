# Simple Admin App

A small admin application with a React frontend, Python backend, and MySQL database running in Docker.

## Features

- Login screen with token-based session storage
- Dashboard with summary cards, recent activity, and role mix
- User management with create, edit, delete, role, status, and search controls
- MySQL database persistence through Docker
- Professional responsive UI with CSS animations

## Requirements

Install these before running the project:

- Node.js
- Python 3.10 or newer
- Docker Desktop

## Start MySQL Database

From the project root, run:

```bash
docker compose up -d
```

This starts MySQL with these details:

```text
Host: 127.0.0.1
Port: 3306
Database: admin_db
Username: admin
Password: admin123
Root password: root123
```

To stop the database:

```bash
docker compose down
```

To stop and delete the database data:

```bash
docker compose down -v
```

## Run The Backend

Install Python packages once:

```bash
cd backend
pip install -r requirements.txt
```

Then run:

```bash
python app.py
```

The API will run at `http://localhost:8000`.

Default login:

- Email: `admin@example.com`
- Password: `admin123`

## Run The Frontend

Install Node.js packages once:

```bash
cd frontend
npm install
```

Then run:

```bash
npm run dev
```

The React app will run at `http://localhost:5173`.

## Main API Routes

```text
POST   /api/login
GET    /api/dashboard
GET    /api/users
POST   /api/users
PUT    /api/users/:id
DELETE /api/users/:id
```