from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
import time
from urllib.parse import urlparse

import mysql.connector
from mysql.connector import Error

HOST = "localhost"
PORT = 8000
ADMIN_EMAIL = "admin@example.com"
ADMIN_PASSWORD = "admin123"
AUTH_TOKEN = "demo-admin-token"

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "127.0.0.1"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "admin"),
    "password": os.getenv("DB_PASSWORD", "admin123"),
    "database": os.getenv("DB_NAME", "admin_db"),
}

SEED_USERS = [
    ("Aarav Sharma", "aarav@example.com", "Admin", "Active"),
    ("Maya Patel", "maya@example.com", "Manager", "Active"),
    ("Neha Rao", "neha@example.com", "Editor", "Inactive"),
]

SEED_ACTIVITY = [
    "Maya Patel updated billing settings",
    "Aarav Sharma invited a new manager",
    "Neha Rao changed account status",
]


def get_connection():
    return mysql.connector.connect(**DB_CONFIG)


def wait_for_database(max_attempts=30):
    for attempt in range(1, max_attempts + 1):
        try:
            connection = get_connection()
            connection.close()
            return
        except Error:
            if attempt == max_attempts:
                raise
            print(f"Waiting for MySQL to be ready... ({attempt}/{max_attempts})")
            time.sleep(2)


def init_database():
    wait_for_database()
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(120) NOT NULL,
                email VARCHAR(160) NOT NULL UNIQUE,
                role ENUM('Admin', 'Manager', 'Editor', 'Viewer') NOT NULL DEFAULT 'Viewer',
                status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS activity (
                id INT AUTO_INCREMENT PRIMARY KEY,
                message VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cursor.execute("SELECT COUNT(*) FROM users")
        if cursor.fetchone()[0] == 0:
            cursor.executemany(
                "INSERT INTO users (name, email, role, status) VALUES (%s, %s, %s, %s)",
                SEED_USERS,
            )
        cursor.execute("SELECT COUNT(*) FROM activity")
        if cursor.fetchone()[0] == 0:
            cursor.executemany(
                "INSERT INTO activity (message) VALUES (%s)",
                [(message,) for message in SEED_ACTIVITY],
            )
        connection.commit()


class AdminApiHandler(BaseHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_POST(self):
        path = urlparse(self.path).path

        if path == "/api/login":
            payload = self.read_json()
            if payload.get("email") == ADMIN_EMAIL and payload.get("password") == ADMIN_PASSWORD:
                return self.write_json(
                    {
                        "token": AUTH_TOKEN,
                        "user": {"name": "Admin User", "email": ADMIN_EMAIL, "role": "Administrator"},
                    }
                )
            return self.write_json({"message": "Invalid email or password"}, status=401)

        if path == "/api/users":
            if not self.is_authorized():
                return self.write_json({"message": "Unauthorized"}, status=401)

            payload = self.read_json()
            user = {
                "name": payload.get("name", "").strip(),
                "email": payload.get("email", "").strip(),
                "role": payload.get("role", "Viewer"),
                "status": payload.get("status", "Active"),
            }

            error = validate_user(user)
            if error:
                return self.write_json({"message": error}, status=400)

            try:
                created_user = create_user(user)
                add_activity(f"{created_user['name']} was added as {created_user['role']}")
                return self.write_json(created_user, status=201)
            except Error as database_error:
                if database_error.errno == 1062:
                    return self.write_json({"message": "Email already exists"}, status=400)
                return self.write_json({"message": "Database error"}, status=500)

        self.write_json({"message": "Not found"}, status=404)

    def do_GET(self):
        path = urlparse(self.path).path

        if path.startswith("/api/") and not self.is_authorized():
            return self.write_json({"message": "Unauthorized"}, status=401)

        if path == "/api/dashboard":
            return self.write_json(get_dashboard())

        if path == "/api/users":
            return self.write_json(get_users())

        self.write_json({"message": "Not found"}, status=404)

    def do_PUT(self):
        path = urlparse(self.path).path

        if not self.is_authorized():
            return self.write_json({"message": "Unauthorized"}, status=401)

        if path.startswith("/api/users/"):
            user_id = parse_id(path)
            existing_user = find_user(user_id)
            if not existing_user:
                return self.write_json({"message": "User not found"}, status=404)

            payload = self.read_json()
            updated_user = {
                "id": user_id,
                "name": payload.get("name", existing_user["name"]).strip(),
                "email": payload.get("email", existing_user["email"]).strip(),
                "role": payload.get("role", existing_user["role"]),
                "status": payload.get("status", existing_user["status"]),
            }

            error = validate_user(updated_user)
            if error:
                return self.write_json({"message": error}, status=400)

            try:
                saved_user = update_user(updated_user)
                add_activity(f"{saved_user['name']} was updated")
                return self.write_json(saved_user)
            except Error as database_error:
                if database_error.errno == 1062:
                    return self.write_json({"message": "Email already exists"}, status=400)
                return self.write_json({"message": "Database error"}, status=500)

        self.write_json({"message": "Not found"}, status=404)

    def do_DELETE(self):
        path = urlparse(self.path).path

        if not self.is_authorized():
            return self.write_json({"message": "Unauthorized"}, status=401)

        if path.startswith("/api/users/"):
            user_id = parse_id(path)
            existing_user = find_user(user_id)
            if not existing_user:
                return self.write_json({"message": "User not found"}, status=404)

            delete_user(user_id)
            add_activity(f"{existing_user['name']} was removed")
            return self.write_json({"message": "User deleted"})

        self.write_json({"message": "Not found"}, status=404)

    def read_json(self):
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw_body = self.rfile.read(length).decode("utf-8")
        return json.loads(raw_body)

    def write_json(self, data, status=200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def is_authorized(self):
        return self.headers.get("Authorization") == f"Bearer {AUTH_TOKEN}"


def get_users():
    with get_connection() as connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id, name, email, role, status FROM users ORDER BY id")
        return cursor.fetchall()


def find_user(user_id):
    if user_id is None:
        return None
    with get_connection() as connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id, name, email, role, status FROM users WHERE id = %s", (user_id,))
        return cursor.fetchone()


def create_user(user):
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            "INSERT INTO users (name, email, role, status) VALUES (%s, %s, %s, %s)",
            (user["name"], user["email"], user["role"], user["status"]),
        )
        connection.commit()
        return find_user(cursor.lastrowid)


def update_user(user):
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            UPDATE users
            SET name = %s, email = %s, role = %s, status = %s
            WHERE id = %s
            """,
            (user["name"], user["email"], user["role"], user["status"], user["id"]),
        )
        connection.commit()
        return find_user(user["id"])


def delete_user(user_id):
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
        connection.commit()


def add_activity(message):
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute("INSERT INTO activity (message) VALUES (%s)", (message,))
        connection.commit()


def get_activity():
    with get_connection() as connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT message FROM activity ORDER BY id DESC LIMIT 5")
        return [row["message"] for row in cursor.fetchall()]


def get_dashboard():
    users = get_users()
    active_users = len([user for user in users if user["status"] == "Active"])
    return {
        "stats": {
            "totalUsers": len(users),
            "activeUsers": active_users,
            "inactiveUsers": len(users) - active_users,
            "admins": len([user for user in users if user["role"] == "Admin"]),
        },
        "activity": get_activity(),
    }


def parse_id(path):
    try:
        return int(path.rstrip("/").split("/")[-1])
    except ValueError:
        return None


def validate_user(user):
    if not user["name"]:
        return "Name is required"
    if "@" not in user["email"]:
        return "Valid email is required"
    if user["role"] not in ["Admin", "Manager", "Editor", "Viewer"]:
        return "Invalid role"
    if user["status"] not in ["Active", "Inactive"]:
        return "Invalid status"
    return None


if __name__ == "__main__":
    try:
        init_database()
    except Error as error:
        print("Could not connect to MySQL. Start Docker MySQL first with: docker compose up -d, then wait until it is healthy.")
        raise error

    server = HTTPServer((HOST, PORT), AdminApiHandler)
    print(f"Admin API running at http://{HOST}:{PORT}")
    server.serve_forever()