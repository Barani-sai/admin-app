import React from "react";
import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  Bell,
  CheckCircle2,
  ChevronRight,
  LayoutDashboard,
  LogOut,
  Mail,
  Pencil,
  Plus,
  Search,
  ShieldCheck,
  Sparkles,
  Trash2,
  Users,
} from "lucide-react";

const API_BASE_URL = "http://localhost:8000/api";
const emptyForm = { name: "", email: "", role: "Viewer", status: "Active" };

function App() {
  const [session, setSession] = useState(() => {
    const savedSession = localStorage.getItem("adminSession");
    return savedSession ? JSON.parse(savedSession) : null;
  });
  const [view, setView] = useState("dashboard");
  const [dashboard, setDashboard] = useState(null);
  const [users, setUsers] = useState([]);
  const [query, setQuery] = useState("");
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [loginForm, setLoginForm] = useState({ email: "admin@example.com", password: "admin123" });
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const authHeaders = useMemo(
    () => ({
      "Content-Type": "application/json",
      Authorization: `Bearer ${session?.token}`,
    }),
    [session]
  );

  useEffect(() => {
    if (!session) return;
    loadDashboard();
    loadUsers();
  }, [session]);

  async function request(path, options = {}) {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers: { ...authHeaders, ...options.headers },
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "Something went wrong");
    return data;
  }

  async function handleLogin(event) {
    event.preventDefault();
    setError("");
    setIsLoading(true);

    try {
      const response = await fetch(`${API_BASE_URL}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loginForm),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message);
      localStorage.setItem("adminSession", JSON.stringify(data));
      setSession(data);
    } catch (loginError) {
      setError(loginError.message);
    } finally {
      setIsLoading(false);
    }
  }

  async function loadDashboard() {
    setDashboard(await request("/dashboard"));
  }

  async function loadUsers() {
    setUsers(await request("/users"));
  }

  async function handleSaveUser(event) {
    event.preventDefault();
    setError("");

    try {
      await request(editingId ? `/users/${editingId}` : "/users", {
        method: editingId ? "PUT" : "POST",
        body: JSON.stringify(form),
      });
      setForm(emptyForm);
      setEditingId(null);
      await loadUsers();
      await loadDashboard();
    } catch (saveError) {
      setError(saveError.message);
    }
  }

  async function handleDeleteUser(userId) {
    await request(`/users/${userId}`, { method: "DELETE" });
    await loadUsers();
    await loadDashboard();
  }

  function handleEditUser(user) {
    setEditingId(user.id);
    setForm({ name: user.name, email: user.email, role: user.role, status: user.status });
  }

  function handleLogout() {
    localStorage.removeItem("adminSession");
    setSession(null);
    setDashboard(null);
    setUsers([]);
    setView("dashboard");
  }

  const filteredUsers = users.filter((user) => {
    const haystack = `${user.name} ${user.email} ${user.role} ${user.status}`.toLowerCase();
    return haystack.includes(query.toLowerCase());
  });

  if (!session) {
    return (
      <main className="login-shell">
        <div className="ambient ambient-one" />
        <div className="ambient ambient-two" />
        <section className="login-panel" aria-labelledby="login-title">
          <div className="login-copy">
            <span className="brand-mark"><ShieldCheck size={22} /></span>
            <p className="eyebrow">Secure workspace</p>
            <h1 id="login-title">Admin Console</h1>
            <p>Manage users, roles, and account status from a focused operations dashboard.</p>
          </div>

          <form onSubmit={handleLogin} className="stack">
            <label>Email<input type="email" value={loginForm.email} onChange={(event) => setLoginForm({ ...loginForm, email: event.target.value })} required /></label>
            <label>Password<input type="password" value={loginForm.password} onChange={(event) => setLoginForm({ ...loginForm, password: event.target.value })} required /></label>
            {error && <p className="error">{error}</p>}
            <button className="primary-button" type="submit" disabled={isLoading}>
              {isLoading ? "Signing in..." : "Login"}<ChevronRight size={18} />
            </button>
          </form>
        </section>
      </main>
    );
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand"><ShieldCheck /><span>Admin Console</span></div>
        <nav>
          <button className={view === "dashboard" ? "active" : ""} onClick={() => setView("dashboard")}><LayoutDashboard size={18} />Dashboard</button>
          <button className={view === "users" ? "active" : ""} onClick={() => setView("users")}><Users size={18} />User Management</button>
        </nav>
        <div className="sidebar-card"><Sparkles size={18} /><span>System health is stable</span></div>
        <button className="logout-button" onClick={handleLogout}><LogOut size={18} />Logout</button>
      </aside>

      <main className="content">
        <header className="topbar">
          <div>
            <p className="eyebrow">Welcome back</p>
            <h1>{view === "dashboard" ? "Dashboard" : "User Management"}</h1>
          </div>
          <div className="topbar-actions">
            <button className="icon-button" title="Notifications"><Bell size={18} /></button>
            <div className="profile-pill"><span>{session.user.name}</span><strong>{session.user.role}</strong></div>
          </div>
        </header>

        <section className="view-stage" key={view}>
          {view === "dashboard" ? (
            <Dashboard dashboard={dashboard} users={users} />
          ) : (
            <UserManagement
              users={filteredUsers}
              query={query}
              setQuery={setQuery}
              form={form}
              setForm={setForm}
              editingId={editingId}
              setEditingId={setEditingId}
              onSave={handleSaveUser}
              onEdit={handleEditUser}
              onDelete={handleDeleteUser}
              error={error}
            />
          )}
        </section>
      </main>
    </div>
  );
}

function Dashboard({ dashboard, users }) {
  const stats = dashboard?.stats || {};
  const cards = [
    { label: "Total Users", value: stats.totalUsers ?? "-", icon: Users, tone: "teal" },
    { label: "Active Users", value: stats.activeUsers ?? "-", icon: CheckCircle2, tone: "green" },
    { label: "Inactive Users", value: stats.inactiveUsers ?? "-", icon: Activity, tone: "rose" },
    { label: "Admins", value: stats.admins ?? "-", icon: ShieldCheck, tone: "amber" },
  ];

  return (
    <div className="dashboard-grid">
      <section className="stats-grid">
        {cards.map((card, index) => <StatCard key={card.label} card={card} index={index} />)}
      </section>

      <section className="panel wide-panel">
        <div className="panel-heading"><div><p className="eyebrow">Audit trail</p><h2>Recent Activity</h2></div><Activity size={20} /></div>
        <ul className="activity-list">
          {(dashboard?.activity || []).map((item, index) => <li style={{ animationDelay: `${index * 70}ms` }} key={item}>{item}</li>)}
        </ul>
      </section>

      <section className="panel">
        <div className="panel-heading"><div><p className="eyebrow">Team access</p><h2>Role Mix</h2></div><Users size={20} /></div>
        <div className="role-bars">
          {["Admin", "Manager", "Editor", "Viewer"].map((role) => {
            const count = users.filter((user) => user.role === role).length;
            const percent = users.length ? Math.max((count / users.length) * 100, 8) : 8;
            return <div className="role-row" key={role}><span>{role}</span><div><i style={{ width: `${percent}%` }} /></div><strong>{count}</strong></div>;
          })}
        </div>
      </section>
    </div>
  );
}

function StatCard({ card, index }) {
  return (
    <article className={`stat-card ${card.tone}`} style={{ animationDelay: `${index * 80}ms` }}>
      <span className="stat-icon"><card.icon size={22} /></span>
      <span>{card.label}</span>
      <strong>{card.value}</strong>
    </article>
  );
}

function UserManagement(props) {
  const { users, query, setQuery, form, setForm, editingId, setEditingId, onSave, onEdit, onDelete, error } = props;
  return (
    <section className="users-layout">
      <form className="panel user-form" onSubmit={onSave}>
        <div className="panel-heading"><div><p className="eyebrow">{editingId ? "Update account" : "Create account"}</p><h2>{editingId ? "Edit User" : "Add User"}</h2></div><Plus size={20} /></div>
        <label>Name<input value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="Full name" required /></label>
        <label>Email<input type="email" value={form.email} onChange={(event) => setForm({ ...form, email: event.target.value })} placeholder="user@example.com" required /></label>
        <label>Role<select value={form.role} onChange={(event) => setForm({ ...form, role: event.target.value })}><option>Admin</option><option>Manager</option><option>Editor</option><option>Viewer</option></select></label>
        <label>Status<select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value })}><option>Active</option><option>Inactive</option></select></label>
        {error && <p className="error">{error}</p>}
        <div className="form-actions">
          <button className="primary-button" type="submit">{editingId ? "Save Changes" : "Create User"}<ChevronRight size={18} /></button>
          {editingId && <button type="button" className="ghost-button" onClick={() => { setEditingId(null); setForm(emptyForm); }}>Cancel</button>}
        </div>
      </form>

      <section className="panel user-table-panel">
        <div className="table-tools"><div className="search-box"><Search size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search users" /></div></div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {users.map((user, index) => (
                <tr key={user.id} style={{ animationDelay: `${index * 45}ms` }}>
                  <td><strong>{user.name}</strong></td>
                  <td><span className="email-cell"><Mail size={16} />{user.email}</span></td>
                  <td>{user.role}</td>
                  <td><span className={`status ${user.status.toLowerCase()}`}>{user.status}</span></td>
                  <td><div className="row-actions"><button type="button" title="Edit user" onClick={() => onEdit(user)}><Pencil size={16} /></button><button type="button" title="Delete user" onClick={() => onDelete(user.id)}><Trash2 size={16} /></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}

export default App;
